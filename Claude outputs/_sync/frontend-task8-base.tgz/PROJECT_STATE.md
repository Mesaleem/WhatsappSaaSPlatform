# wa-saas-platform — Project State

> **Read this file first.** It is the single, continuously-updated description of what this
> project is, what is built, and what is pending. It is maintained at the end of every
> development task. If you were asked to "analyze the project", start here, then open the
> files it points at — do not reconstruct the picture from scratch.

| | |
|---|---|
| **Last updated** | 2026-09-23 |
| **Last completed work** | CRM Task 7 — Lead Tags & Segmentation Foundation |
| **Backend test suite** | **1170 passed, 0 failures** (MariaDB, authoritative) · 1166 + 4 skipped (SQLite) |
| **Migrations** | 110 |
| **Next up** | CRM Task 8 (not yet specified) |

---

## 1. What This Product Is

A **multi-tenant WhatsApp SaaS platform**. Tenants ("accounts") connect a WhatsApp number
through one of two engines, send templated and bulk messages, capture leads from Meta ads
and social channels, automate replies through a visual journey builder, and are billed
against plan quotas. A Super Admin tier and a reseller ("agent") tier sit above tenants,
with commission tracking for agents.

Three deployable services:

| Directory | Stack | Role |
|---|---|---|
| `backend-api/` | **Laravel 11**, PHP **8.4**, MariaDB **10.11.14**, Sanctum, spatie/laravel-permission | The entire API, business logic, billing, RBAC |
| `frontend-app/` | **React 19.2**, TypeScript 6.0, Vite 8.2, Tailwind 3.4, vitest, oxlint | Tenant + Super Admin web console |
| `qr-engine-service/` | Node, **Baileys 7.0.0-rc14**, Express 5.2, socket.io 4.8 | The QR/Baileys WhatsApp engine (separate process) |

---

## 2. The Two Numbering Schemes — read this before using the word "phase"

⚠️ **There are two different phase numberings in this repo and they do not match.**

1. **The execution track (LIVE — this is what the team actually works to).**
   Phase 1 Foundation → Phase 2/3 Developer API → Phase 4 Meta provider → Phase 5 Journey &
   plan management → **Phase 6 CRM** (current). Tasks are issued as
   "Phase 6 Task N" and each is a self-contained spec.

2. **The architecture report's roadmap** in
   `Claude outputs/wa-saas-platform-architecture-report.md` §27 — Phases 0–10, where
   **Phase 5 = CRM and Phase 6 = AI Platform**. This is the long-range plan, still useful
   for *what is left to build*, but its **numbers are not the ones in use**.

When a task says "Phase 6", it means **CRM**. Section 8 below maps both.

---

## 3. Architecture — the part you must not break

### 3.1 Tenant isolation

`TenantIsolationMiddleware` resolves the request's `account_id`, `is_super_admin` and
`agent_scope_id` from the authenticated user, and every query is scoped through
`ResolvesTenantAccount::requireAccount()` + a model's `scopeForAccount()`.

**`account_id`, `agent_id` and `tenant_id` are never read from the request body or query
string.** Several test suites assert exactly that. Any new endpoint must follow it.

### 3.2 The authorization chain

Every protected route stacks these in order:

```
auth:sanctum
  → tenant.isolation      (who is this, which account)
  → subscription.guard    (is the subscription live)
  → module.guard:<slug>   (is the module enabled for this account)
  → permission:<name>     (spatie RBAC)
  → capability.guard:<slug> (is the account entitled to this capability)
```

Conceptually: **PLAN → ENTITLEMENT → CAPABILITY → PERMISSION → USAGE/QUOTA.**
Middleware aliases live in `bootstrap/app.php`.

### 3.3 Capability / Provider / Plan model

Three independent dimensions, deliberately not bundled — seeded by
`database/seeders/Phase1FoundationSeeder.php`, which is idempotent.

**Capabilities (12):** `whatsapp_send`, `whatsapp_groups`, `crm`, `journey_automation`,
`ads`, `social`, `ai`, `commerce`, `payments`, `external_api`, `custom_code`, `email`.

**Providers (3):** `qr` (Baileys), `meta` (Cloud API), `none`.

**Provider support is a data row, not code.** `provider_capabilities` states every pairing
explicitly with a written reason saying whether a `false` is a technical limitation or a
business rule. Notable rows:

| Provider | Capability | Supported | Why |
|---|---|---|---|
| `qr` | `whatsapp_groups` | ✅ | Real Baileys feature |
| `meta` | `whatsapp_groups` | ❌ | **Technical** — Cloud API has no groups |
| `qr` | `crm` | ✅ | CRM is engine-agnostic |
| `qr` | `journey_automation` | ❌ | **Business tier rule** |
| `qr` | `ads` | ❌ | Business rule + CTWA is Meta-webhook-native |
| `qr` | `commerce` | ❌ | **Technical** — Baileys driver has no catalog messages |

**Plans (3):**

| Slug | Price | Quota | Engine | Bundled capabilities |
|---|---|---|---|---|
| `starter` | ₹499 / 30d | 500 msg | qr | whatsapp_send, whatsapp_groups, social, external_api |
| `growth` | ₹1,999 / 30d | 2,500 msg | qr | + crm, journey_automation, ai, payments, email |
| `business` | ₹7,999 / 30d | 10,000 msg | meta | + ads, commerce, custom_code (no groups) |

**A plan entitlement is not provider support.** `growth` sells `journey_automation` on a QR
engine that does not support it; `InvoiceCreditService::grantPlanEntitlements()` skips the
incompatible pairing at grant time and the Super Admin panel shows it as
*"In plan — provider unsupported"* rather than hiding the conflict. This is intentional.

### 3.4 Modules (17, server-side gated)

`analytics`, `billing`, `chatbot`, `comment_automation`, `contact_groups`, `developer_api`,
`lead_crm`, `message_logs`, `meta_ads`, `notifications`, `reports`, `send_alert`,
`social_accounts`, `social_inbox`, `team_management`, `whatsapp_setup`.

Module-off means **backend-blocked**, not merely UI-hidden.

---

## 4. Database

**110 migrations**, **54 Eloquent models**. Grouped by domain:

| Domain | Key tables |
|---|---|
| Tenancy & RBAC | `accounts`, `users`, `permission_tables`, `activity_logs`, `login_audit_logs`, `system_routes`, `route_categories` |
| Billing | `subscriptions`, `plans`, `plan_entitlements`, `account_entitlements`, `usage_quotas`, `invoices`, `payment_gateway_settings`, `quota_requests` |
| Agent/reseller | `agent_selling_entitlements`, `agent_commission_rules`, `agent_commissions`, `agent_commission_payouts`, `agent_commission_payout_items` |
| Entitlement core | `capabilities`, `providers`, `provider_capabilities` |
| WhatsApp | `whatsapp_sessions`, `message_templates`, `message_dispatch_logs`, `whatsapp_flows`, `whatsapp_flow_sessions` |
| Contacts & groups | `contact_groups`, `contact_group_members` |
| **CRM** | `contacts`, `crm_leads`, `crm_capture_link_failures`, `crm_tags`, `crm_lead_tags` |
| Social & ads | `social_accounts`, `social_provider_configs`, `leads`, `ad_campaigns`, `ad_campaign_daily_metrics`, `organic_posts`, `comment_automation_rules`, `comment_automation_events` |
| Developer API | `api_keys`, `api_request_logs`, `api_idempotency_keys`, `webhook_subscriptions`, `webhook_deliveries` |
| Chatbot & notifications | `chatbot_rules`, `chatbot_logs`, `notification_templates`, `notification_broadcasts`, `in_app_notifications`, `mail_settings`, `mail_logs` |

**Schema invariants that must not be violated:**

- `crm_leads.status` is the **only** CRM status field. No `pipeline_status`, `pipeline_stage`,
  `kanban_status`, `custom_status` or `stage` column exists — re-verified each CRM task.
- `crm_leads.assigned_user_id` is the **only** ownership field. No `owner_id`/`sales_owner_id`.
- **Tags are metadata, not status.** They live only in `crm_tags` / `crm_lead_tags`; every
  assignment row's `account_id` is bound to both the lead and the tag by composite FKs, so a
  cross-tenant pairing is unstorable. Tag names are unique per account case-insensitively
  (`normalized_name`, binary collation).
- **No model uses `SoftDeletes`.** The architecture report recommends adding it to `accounts`,
  `invoices`, `subscriptions`, `message_templates`; that has **not** been done.

---

## 5. API Surface

### Internal API (`/api/...`) — consumed by `frontend-app`

Prefixes: `admin`, `alerts`, `analytics`, `audit-logs`, `billing`, `chatbot`, `contacts`,
`crm`, `developer`, `exports`, `groups`, `leads`, `message-templates`,
`notification-broadcasts`, `notification-templates`, `social`, `team`, `whatsapp`.

### CRM surface (complete as of Task 7)

| Route | Verb | Purpose |
|---|---|---|
| `/api/crm/contacts` | GET POST | Contact list & creation |
| `/api/crm/contacts/{id}` | GET PATCH DELETE | Contact detail |
| `/api/crm/contacts/{id}/leads` | GET | A contact's leads |
| `/api/crm/leads` | GET POST | Lead list & creation; list filters `?tag_id=` / `?tag_ids[]=` (AND) |
| `/api/crm/leads/{id}` | GET PATCH DELETE | Lead detail |
| `/api/crm/leads/{id}/assignee` | PATCH | **The** ownership mutation API |
| `/api/crm/leads/{id}/status` | PATCH | **The** lifecycle mutation API |
| `/api/crm/assignees` | GET | Eligible assignees |
| `/api/crm/pipeline` | GET | **Read-only** Kanban view; same tag filters |
| `/api/crm/tags` | GET POST | Tag list (`?search=` prefix, `lead_count`) & creation |
| `/api/crm/tags/{id}` | GET PUT PATCH DELETE | Tag detail / rename / delete |
| `/api/crm/leads/{id}/tags/{tag}` | POST DELETE | Idempotent tag attach / detach (never changes status) |

All carry `module.guard:lead_crm` + `permission:manage-crm` + `capability.guard:crm`.

Lead lifecycle: `new → contacted → converted | not_converted`. Corrections are permitted;
it is not an irreversible state machine.

### Developer API (`/api/v1/...`) — public, API-key authenticated

Separate surface with its own key auth, per-key capability gating
(`capability.apikey`), request logging and idempotency keys.

⚠️ **It is deliberately narrower than the internal API.** CRM assignment, status mutation,
the pipeline and tags were all explicitly **not** exposed there. Do not widen it as a side
effect of internal work.

---

## 6. Test Suite

**40 feature test files** (39 before Task 7, previously miscounted as 40), run with `php artisan test`.

| | SQLite (secondary) | **MariaDB (authoritative)** |
|---|---|---|
| Tests | 1166 passed, 4 skipped | **1170 passed** |
| Assertions | 4353 | 4362 |
| Failures | 0 | **0** |

The 4 SQLite skips are foreign-key tests SQLite cannot express. **MariaDB is authoritative —
a green SQLite run does not compensate for a MariaDB failure.**

Running the suite needs `JOURNEY_REGISTRY_PATH` pointed at
`frontend-app/src/journey/nodeRegistry.tsx` (the backend asserts the journey node palette
against the frontend registry).

---

## 7. Standing Engineering Findings

Established experimentally. These constrain future work — do not re-derive them.

### MariaDB 10.11.14 foreign keys (proven, not assumed)

| Attempt | Result |
|---|---|
| Composite FK + `ON DELETE SET NULL` where any child column is `NOT NULL` | **Refused** — ERROR 1005 / errno 150 |
| `CHECK` constraint over a `SET NULL` column | **Refused** — ERROR 1901 |
| Composite FK + `RESTRICT` | Breaks `DELETE FROM accounts` — ERROR 1451 |
| Composite FK + `CASCADE` | **Works**; account deletion cascades cleanly |

### SQLite cannot `ALTER` foreign keys

All FK migration work is driver-guarded (`in_array($driver, ['mysql','mariadb'])`). A
migration that creates an FK on SQLite makes the later drop fail with *"unknown column in
foreign key definition"*.

### `LogsActivity` is not assertable in tests

`recordActivity()` returns early under `app()->runningInConsole() || !Auth::check()`, so
`activity_logs` rows are **never** written during a test run. Workaround: assert the
`updated` event payload plus `Auth::id()` inside the listener.

### Laravel global middleware changes validation semantics

`ConvertEmptyStringsToNull` ⇒ `''` is `null` everywhere. `TrimStrings` ⇒ `' contacted '`
is `'contacted'`. Write tests against actual behaviour, not assumed behaviour.

### Pre-existing Spatie guard bug (documented, NOT fixed)

All permission rows carry `guard_name: 'web'` while a Sanctum request resolves `'sanctum'`.
Consequence: **`POST /api/roles` returns 500 for every permission**, including pre-existing
ones such as `manage-social-leads` — which is how it was proven pre-existing rather than
CRM-introduced. Tests must build roles **before** the first `actingAs()`.

### Composite FKs declared in `CREATE TABLE` are enforced on SQLite

Only *ALTER*-added FKs are impossible on SQLite. `crm_lead_tags`' composite FKs are declared
in `CREATE TABLE` and are enforced on both engines (Task 7, verified).

### Audit rows can be verified over real HTTP

Under `php artisan serve` against a throwaway MariaDB DB, `LogsActivity` does write
`activity_logs` rows; Task 7 used this for row-level audit verification.

### Unindexed `crm_leads.source`

A `source`-filtered grouped COUNT costs ~116 ms at 120k leads in one tenant. Below the bar
for a new index today; revisit if source-filtered dashboards become a primary access path.

---

## 8. Phase Status — what is built and what is pending

### 8.1 Execution track (live numbering)

| Phase | Scope | Status |
|---|---|---|
| 1 — Foundation | Capabilities, providers, provider_capabilities, plans, entitlements, usage quotas, agent selling entitlements | ✅ **DONE** |
| — Agent commissions | Commission rules, accrual, reversal, payouts | ✅ **DONE** |
| 3 — Developer API | API keys + secrets, request logging, idempotency, webhooks, `/api/v1`, audit | ✅ **DONE** |
| 4 — Meta provider | Meta Cloud API foundation, templates, send, webhook + HMAC hardening, security regression | ✅ **DONE** |
| 5 — Journey & plans | Journey node capability gating, plan→capability matrix, lifecycle reconciliation, DB-backed checkout, entitlement revocation, Super Admin plan management UI | ✅ **DONE** |
| **6 — CRM** | Contacts, leads, linking, assignment, lifecycle, pipeline, tags | 🟡 **IN PROGRESS — Tasks 1–7 done** |

#### CRM (Phase 6) task-by-task

| # | Task | Status | Migration | Suite total after |
|---|---|---|---|---|
| 1 | CRM Domain & Database Foundation | ✅ | 12 CRM migrations | 693 |
| 2 | Lead Creation & Source Management | ✅ | — | 752 |
| H1 | Hardening Round 1 (10 issues) | ✅ (1 deferred, 8 limitations logged) | — | 791 |
| H2 | Hardening Round 2 (all closed) | ✅ | FK moved to `crm_leads.capture_lead_id` | 857 |
| 3 | Contact ↔ Lead Linking | ✅ | none | 909 |
| 4 | Lead Assignment & Ownership | ✅ | none | 960 |
| 5 | Lead Status & Lifecycle | ✅ | none | 1031 |
| 6 | Lead Pipeline & Kanban Foundation | ✅ | none | 1077 |
| 7 | Lead Tags & Segmentation Foundation | ✅ | 3 (`crm_tags`, `crm_lead_tags`, `crm_leads` unique(id, account_id)) | **1170** |
| 8 | *not yet specified* | ⬜ **PENDING** | | |

> Tasks 1–5 and both hardening rounds were reported in full at the time but have no
> standalone file; the figures above are from this project's verified run records.

### 8.2 Long-range roadmap (architecture report §27 numbering)

| Report phase | Scope | Status against code |
|---|---|---|
| 0 — QR stabilization | Login throttling, async bulk upload, real queue worker | ⚠️ **UNVERIFIED** — not confirmed in this codebase; treat as open |
| 1 — Architecture foundation | Provider/plan/billing split, module gates, first real tests | ✅ Done (test suite now 1077, 17 modules gated). ❌ **SoftDeletes never added** |
| 2 — Meta WhatsApp foundation | Productize `MetaCloudApiDriver` | ✅ Done |
| 3 — Meta messaging suite | WABA embedded signup, broadcast parity, unified inbox, Flows/catalog | 🟡 Partial — Flows tables exist; embedded signup and full parity **not** built |
| 4 — Automation engine | `delay`/`wait` node, recurring triggers, paused-execution persistence | 🟡 Partial — a `delay` node exists in the journey registry, but **no `flow_executions` / `pending_steps` table exists**, so a durable paused-until-timestamp instance is not implemented |
| 5 — CRM *(= execution Phase 6)* | Contact/Lead/**Deal/Pipeline/Stage/Task/Note/Tag** | 🟡 Contacts, Leads, a status-based pipeline and tenant-scoped lead **tags** exist. **No `deals`, `crm_tasks` or `crm_notes` tables** |
| 6 — AI Platform | Content generation + append-only credit ledger | ❌ **NOT BUILT** — no `ai_credit_transactions` table |
| 7 — Social media | LinkedIn OAuth, organic scheduling/analytics | 🟡 Meta only. `SocialOAuthProviderFactory` **throws** for `linkedin` and `google` |
| 8 — Catalog/ecommerce | Commerce capability | ❌ Capability seeded; no implementation |
| 9 — Ads + attribution | Full ad → deal → conversion chain | ❌ Blocked on a Deal model existing |
| 10 — Advanced analytics | Extend analytics to CRM/AI/Ads data | ❌ Not started |

### 8.3 Confirmed gaps (verified against code, not inferred)

- **No CRM frontend.** `frontend-app/src/pages` has no `crm` directory. The entire CRM is
  backend-only. The pipeline endpoint was built specifically as the foundation for one.
- **No Deal / Task / Note entities** — the CRM is Contact + Lead + lead Tags only.
- **No AI credit ledger.**
- **No durable journey-execution persistence** (no paused-step table).
- **No soft deletes anywhere.**
- **LinkedIn / Google OAuth unimplemented** — the factory throws by design.
- **`POST /api/roles` is broken** by the Spatie guard mismatch (§7).

---

## 9. Working Conventions

### Frontend page layout

See `CLAUDE.md`. Use **Pattern A** (plain `p-6` wrapper, no duplicate header) for new
pages; `PageShell`/`PageHeader` is legacy.

### Verification pipeline applied to every backend task

1. Targeted suite for the new work
2. Full SQLite suite (secondary)
3. Fresh **throwaway** MariaDB database → full suite (**authoritative**)
4. Migration forward → rollback → forward, **throwaway database only**
5. `EXPLAIN` on MariaDB with realistically seeded data, where query shape changed
6. `php -l` on every changed file + `php artisan route:list`
7. md5 drift-compare before committing
8. `expectedMtimeMs`-guarded commit, then md5 re-verification

### State protection (non-negotiable)

**The real database `wa_saas_platform` is never migrated, seeded or written to by
development tooling.** All schema work uses throwaway databases. `RefreshDatabase` wipes
its target — never point a test run at the real database.

### Task discipline

Tasks arrive as tightly-scoped specs. The standing rules: inspect existing code before
proposing changes; gap-fill rather than rebuild; preserve QR/Baileys, Meta, Journey and
billing behaviour; no unrelated refactors; never weaken, skip or delete existing tests;
full regression on both engines; do not widen `/api/v1` as a side effect.

---

## 10. Keeping This File Current

**Update this file at the end of every task**, before reporting completion. At minimum:

- the header table (date, last completed work, suite totals, migration count, next up)
- §8.1's task table — new row, status, migration, new suite total
- §8.3 if a confirmed gap was closed or a new one found
- §7 if a new standing finding was established
- §4/§5 if the schema or API surface changed

Reference documents (historical, **not** maintained):
`Claude outputs/wa-saas-platform-architecture-report.md` (the long-range roadmap, §27),
`Claude outputs/wa-saas-platform-phase1-foundation-plan.md`, and ~40 dated audit files in
`Claude outputs/`. They are snapshots of their date — **this file supersedes them wherever
they disagree.**
