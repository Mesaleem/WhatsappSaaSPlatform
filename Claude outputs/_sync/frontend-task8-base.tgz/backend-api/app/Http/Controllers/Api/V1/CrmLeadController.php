<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Account;
use App\Models\CrmLead;
use App\Services\Crm\CrmLeadService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Phase 6 — CRM Hardening Round 2, Issue 1. The external Developer API's
 * CRM lead intake.
 *
 * ============================== API DOCS ==============================
 * POST /api/v1/crm/leads
 *
 * AUTH
 *   X-API-KEY: <client api key>        (or Authorization: Bearer <key>)
 *   The key identifies the tenant. There is no user on this request.
 *
 * REQUIRES
 *   The key's account must hold the `crm` capability (i.e. its plan must
 *   include CRM). Without it: 403 CAPABILITY_NOT_ENTITLED.
 *
 * BODY
 *   phone_number          required, string, max 32. Normalized server
 *                         side with the platform's PhoneNumberNormalizer;
 *                         an existing contact with the same normalized
 *                         number is reused, never duplicated.
 *   name                  optional, string, max 255. Fills the contact's
 *                         name only when it is currently blank.
 *   email                 optional, email, max 255. Same fill-if-blank rule.
 *   status                optional, one of: new | contacted | converted |
 *                         not_converted. Defaults to `new`.
 *   not_converted_reason  optional, string, max 255.
 *
 * NOT ACCEPTED — sending these changes nothing:
 *   account_id   The tenant comes from the API key. Always.
 *   source       Forced to `api` server side; a caller cannot label its
 *                leads as meta_ad, journey or whatsapp and so cannot
 *                pollute source attribution.
 *   assigned_user_id  There is no user on an API-key request to
 *                authorize an assignment against; assignment is done
 *                from the tenant-authenticated API.
 *
 * RESPONSES
 *   201 { success, message, data: { id, status, source, contact:{...},
 *         created_at } }
 *   401 invalid/missing/revoked/expired key — AuthenticateApiKey's
 *       existing contract, unchanged.
 *   403 CAPABILITY_NOT_ENTITLED — the plan does not include CRM.
 *   422 validation errors, standard { message, errors:{field:[...]} }.
 *   429 throttle:external-api, unchanged.
 *   Idempotency-Key is honoured exactly as on every other /v1 route.
 * ======================================================================
 *
 * WHY NOT ALSO LIST/UPDATE/DELETE HERE: the brief asks for CRM lead
 * CREATION from the Developer API. Read and lifecycle endpoints would be
 * a new external surface nobody asked for, and the tenant-authenticated
 * /api/crm/* API already provides them.
 *
 * ORDINARY OUTBOUND MESSAGE ENDPOINTS ARE UNTOUCHED. Sending a message
 * through /api/v1/messages/* still creates no CRM lead — a CRM lead is
 * created only by this explicit intake operation.
 */
class CrmLeadController extends Controller
{
    public function __construct(private readonly CrmLeadService $leads)
    {
    }

    public function store(Request $request): JsonResponse
    {
        $accountId = $request->attributes->get('api_account_id');

        // Defensive only — AuthenticateApiKey guarantees this for any
        // request that reaches this controller. Same shape
        // ExternalAlertController already uses.
        abort_if(! $accountId, 401, 'Unauthenticated.');

        $account = Account::find($accountId);
        abort_if(! $account, 401, 'Unauthenticated.');

        $data = $request->validate([
            'phone_number' => ['required', 'string', 'max:32'],
            'name' => ['nullable', 'string', 'max:255'],
            'email' => ['nullable', 'email', 'max:255'],
            'status' => ['nullable', 'string', \Illuminate\Validation\Rule::in(CrmLead::STATUSES)],
            'not_converted_reason' => ['nullable', 'string', 'max:255'],
        ]);

        /*
         * source is OVERWRITTEN, not defaulted. Building the service
         * payload from $data by key rather than merging means a body
         * containing "source": "meta_ad" cannot reach CrmLeadService at
         * all — there is no path by which a caller-supplied source
         * survives. Same for account_id and assigned_user_id, which are
         * not in the validated set and are therefore never read.
         */
        $lead = $this->leads->create($account, [
            'phone_number' => $data['phone_number'],
            'name' => $data['name'] ?? null,
            'email' => $data['email'] ?? null,
            'status' => $data['status'] ?? CrmLead::STATUS_NEW,
            'not_converted_reason' => $data['not_converted_reason'] ?? null,
            'source' => CrmLead::SOURCE_API,
        ]);

        $lead->load('contact');

        return response()->json([
            'success' => true,
            'message' => 'Lead created.',
            'data' => [
                'id' => $lead->id,
                'status' => $lead->status,
                'source' => $lead->source,
                'contact' => [
                    'id' => $lead->contact->id,
                    'name' => $lead->contact->name,
                    'phone_number' => $lead->contact->phone_number,
                    'email' => $lead->contact->email,
                ],
                'created_at' => $lead->created_at?->toIso8601String(),
            ],
        ], 201);
    }
}
