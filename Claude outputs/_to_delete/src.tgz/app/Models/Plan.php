<?php

namespace App\Models;

use App\Traits\LogsActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Plan extends Model
{
    use LogsActivity;

    protected $fillable = ['slug', 'label', 'price', 'duration_days', 'description'];

    protected function casts(): array
    {
        return [
            'price' => 'decimal:2',
            'duration_days' => 'integer',
        ];
    }

    public function capabilities(): BelongsToMany
    {
        return $this->belongsToMany(Capability::class, 'plan_entitlements')
            ->withPivot('usage_limit')
            ->withTimestamps();
    }
}
