<?php

namespace App\Models;

use App\Traits\LogsActivity;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Cache;

class AccountEntitlement extends Model
{
    use LogsActivity;

    protected $fillable = ['account_id', 'capability_id', 'source', 'granted_by_account_id'];

    /**
     * Phase 1 Foundation, Task 10 — reuses Account::cacheKey()/its own
     * booted()-hook invalidation pattern exactly, so a grant/revoke here
     * is never served stale by AccessControlService::canTenant() via
     * Account::findCached()'s 60-minute TTL. Mirrors Account.php's own
     * booted() hook rather than inventing a second caching convention.
     */
    protected static function booted(): void
    {
        static::saved(fn (AccountEntitlement $e) => Cache::forget(Account::cacheKey($e->account_id)));
        static::deleted(fn (AccountEntitlement $e) => Cache::forget(Account::cacheKey($e->account_id)));
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(Account::class);
    }

    public function capability(): BelongsTo
    {
        return $this->belongsTo(Capability::class);
    }

    public function grantedBy(): BelongsTo
    {
        return $this->belongsTo(Account::class, 'granted_by_account_id');
    }
}
