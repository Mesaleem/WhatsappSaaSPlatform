<?php

namespace App\Services\Access;

use App\Models\Capability;
use App\Models\Provider;
use App\Models\ProviderCapability;
use Illuminate\Support\Facades\Cache;

/**
 * Phase 1 Foundation — the single, data-driven answer to "is this
 * capability even possible/allowed on this provider". Replaces
 * scattered `engine_type === 'qr'` string checks. See the Phase 1 plan,
 * Step 6.
 *
 * No row for a given (provider, capability) pair means "no restriction
 * stated" -> true, matching this codebase's own allowed_modules "null =
 * everything enabled" convention (Account::effectiveModules()) rather
 * than failing closed for capabilities nobody has ever restricted
 * (e.g. 'crm'/'social'/'ai' against most providers).
 */
class ProviderCapabilityService
{
    private const CACHE_TTL_SECONDS = 3600;

    public function supports(Provider|string $provider, Capability|string $capability): bool
    {
        $providerSlug = $provider instanceof Provider ? $provider->slug : $provider;
        $capabilitySlug = $capability instanceof Capability ? $capability->slug : $capability;

        return Cache::remember(
            "provider_capability:{$providerSlug}:{$capabilitySlug}",
            self::CACHE_TTL_SECONDS,
            function () use ($providerSlug, $capabilitySlug) {
                $row = ProviderCapability::query()
                    ->whereHas('provider', fn ($q) => $q->where('slug', $providerSlug))
                    ->whereHas('capability', fn ($q) => $q->where('slug', $capabilitySlug))
                    ->first();

                return $row === null ? true : (bool) $row->supported;
            }
        );
    }

    /**
     * The reason string for a false/blocked pairing, or null when
     * supported (or unrestricted). Lets callers surface WHY a grant was
     * rejected — see AccountEntitlementController.
     */
    public function reasonIfUnsupported(Provider|string $provider, Capability|string $capability): ?string
    {
        $providerSlug = $provider instanceof Provider ? $provider->slug : $provider;
        $capabilitySlug = $capability instanceof Capability ? $capability->slug : $capability;

        $row = ProviderCapability::query()
            ->whereHas('provider', fn ($q) => $q->where('slug', $providerSlug))
            ->whereHas('capability', fn ($q) => $q->where('slug', $capabilitySlug))
            ->first();

        if ($row === null || $row->supported) {
            return null;
        }

        return $row->reason ?? 'This capability is not supported on this provider.';
    }
}
