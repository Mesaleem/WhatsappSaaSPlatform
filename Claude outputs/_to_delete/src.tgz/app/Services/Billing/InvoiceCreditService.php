<?php

namespace App\Services\Billing;

use App\Models\Account;
use App\Models\AccountEntitlement;
use App\Models\AgentCommission;
use App\Models\AgentCommissionRule;
use App\Models\Invoice;
use App\Models\Plan;
use App\Models\Subscription;
use App\Services\Access\ProviderCapabilityService;
use App\Support\PlanCatalog;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * The single place money becomes quota. Called from BOTH
 * PaymentGatewayController::verifyPayment() (fast, client-triggered,
 * optimistic) AND PaymentWebhookController's two handlers (authoritative,
 * async, the one actually meant to be trusted) — a real production race
 * between "the browser calls verify-payment" and "the gateway's webhook
 * arrives" is expected, not an edge case, so this MUST be idempotent
 * under concurrent calls for the same invoice. That's what the row lock
 * and the "already paid -> no-op" check below are for.
 */
class InvoiceCreditService
{
    public function __construct(private readonly ProviderCapabilityService $providerCapabilities)
    {
    }

    /**
     * @param array<string, mixed>|null $rawResponse
     * @return bool true if this call actually credited the account (first
     *         to win the race); false if it was a no-op (already paid, or
     *         the invoice/plan couldn't be resolved).
     */
    public function markPaidAndCreditQuota(int $invoiceId, string $gatewayPaymentId, ?array $rawResponse = null): bool
    {
        return DB::transaction(function () use ($invoiceId, $gatewayPaymentId, $rawResponse) {
            $invoice = Invoice::query()->lockForUpdate()->find($invoiceId);

            if (! $invoice) {
                Log::warning("InvoiceCreditService: invoice #{$invoiceId} not found.");

                return false;
            }

            // Idempotency guard: whichever of verify-payment / webhook gets
            // here first wins; the other becomes a safe, silent no-op. This
            // is also what makes Agent Commission generation below
            // idempotent under the same duplicate-callback race — a second
            // call for an already-paid invoice never reaches that code at
            // all.
            if ($invoice->isPaid()) {
                return false;
            }

            $plan = PlanCatalog::find($invoice->plan_key);
            if (! $plan) {
                Log::error("InvoiceCreditService: unknown plan_key '{$invoice->plan_key}' on invoice #{$invoice->id}.");

                return false;
            }

            $invoice->forceFill([
                'status' => 'paid',
                'gateway_payment_id' => $gatewayPaymentId,
                'paid_at' => now(),
                'gateway_raw_response' => $rawResponse,
            ])->save();

            $account = Account::find($invoice->account_id);
            if (! $account) {
                Log::error("InvoiceCreditService: account #{$invoice->account_id} not found for invoice #{$invoice->id}.");

                return true; // invoice IS paid — the money was real — just can't credit a missing account.
            }

            $existingSubscription = $account->currentSubscription;
            $subscription = $existingSubscription
                ? Subscription::query()->lockForUpdate()->find($existingSubscription->id)
                : new Subscription(['account_id' => $account->id]);

            // "Extend expiration date" (spec, literal): a renewal on a still-
            // active plan stacks on top of the current expiry rather than
            // resetting the clock to "now + duration"; a lapsed/absent
            // subscription starts a fresh period from now.
            $baseExpiry = ($subscription->expires_at && $subscription->expires_at->isFuture())
                ? $subscription->expires_at
                : now();

            // "Credit allocated message quotas" (spec, literal): additive,
            // not a reset — a tenant upgrading mid-period keeps whatever
            // unused balance they already had. [Inference — disclosed
            // architectural call in the Module 8 report; a "replace on
            // upgrade" model is equally defensible and would be a one-line
            // change here if that's what's actually wanted.]
            $subscription->engine_type = $plan['engine_type'];
            $subscription->billing_model = $plan['billing_model'];
            $subscription->rate_per_message = $plan['rate_per_message'];
            $subscription->total_allocated_messages = $plan['billing_model'] === 'unlimited'
                ? null
                : ($subscription->total_allocated_messages ?? 0) + $plan['total_allocated_messages'];
            $subscription->price_paid = (float) ($subscription->price_paid ?? 0) + (float) $invoice->total_amount;
            $subscription->payment_mode = $invoice->payment_gateway;
            $subscription->starts_at = $subscription->starts_at ?? now();
            $subscription->expires_at = $baseExpiry->copy()->addDays($plan['duration_days']);
            $subscription->status = 'active';
            $subscription->save();

            // Phase 1 Foundation — Plan -> Entitlement auto-grant, inside
            // this SAME transaction: a payment can never be marked
            // successful while entitlement granting silently fails (any
            // exception here rolls back the invoice/subscription changes
            // above too, same as every other line in this method).
            $this->grantPlanEntitlements($account, $subscription, $invoice->plan_key);

            // Agent Commission Foundation — same transaction boundary and
            // idempotency guard as the entitlement grant above: generated
            // only once per successfully-paid Invoice, and only when this
            // customer actually belongs to an Agent.
            $this->grantAgentCommission($account, $invoice);

            return true;
        });
    }

    /**
     * Looked up by Plan::slug === Invoice::plan_key — Phase1FoundationSeeder's
     * own docblock: "Plan rows are value-identical to PlanCatalog::PLANS".
     * PlanCatalog above (the actual quota/pricing source of truth) is
     * untouched; this only ADDS the new Plan catalog's capability bundle
     * as account_entitlements on top of it.
     *
     * firstOrCreate, not updateOrCreate: an entitlement this account
     * already holds for ANY reason (manual Super-Admin grant, Agent
     * delegation, an earlier purchase) is left completely untouched —
     * its original `source`/`granted_by_account_id` survives a later
     * plan purchase that happens to also cover the same capability.
     * Never duplicates a row (unique(account_id, capability_id) plus
     * firstOrCreate's own existence check), and is safe to "re-run" —
     * in practice unreachable without also re-entering the invoice-paid
     * branch above, itself already guarded by Invoice::isPaid().
     *
     * Provider-compatibility reuses ProviderCapabilityService — the
     * exact same data-driven check Task 7/12's grantEntitlement() use —
     * never duplicated here: a plan capability the account's NEW
     * engine_type can't actually support (e.g. a bundled Meta-only
     * capability on a QR-engine plan) is silently skipped, not granted.
     */
    private function grantPlanEntitlements(Account $account, Subscription $subscription, string $planKey): void
    {
        $plan = Plan::where('slug', $planKey)->with('capabilities')->first();

        if (! $plan) {
            // No Plan catalog row for this slug — a disclosed, non-fatal
            // configuration gap (see Phase1FoundationSeeder), never a
            // reason to fail a real, already-credited payment.
            Log::warning("InvoiceCreditService: no Plan row for slug '{$planKey}' -- skipping entitlement grant for account #{$account->id}.");

            return;
        }

        foreach ($plan->capabilities as $capability) {
            if (! $this->providerCapabilities->supports($subscription->engine_type, $capability->slug)) {
                continue;
            }

            AccountEntitlement::firstOrCreate(
                ['account_id' => $account->id, 'capability_id' => $capability->id],
                ['source' => 'plan', 'granted_by_account_id' => null],
            );
        }
    }

    /**
     * Agent Commission Foundation — generates the auditable commission
     * ledger row for this Invoice, if (and only if) the paying customer
     * belongs to an Agent. Direct customers (agent_id === null) never
     * reach the AgentCommissionRule lookup at all — no rule to apply, no
     * row created, by construction rather than a status check.
     *
     * rule_type/rule_value are copied onto the AgentCommission row as a
     * point-in-time snapshot of the AgentCommissionRule that existed at
     * this exact moment — the row's own `amount` is computed from that
     * snapshot, never re-derived from the (possibly since-changed) rule.
     * This is what satisfies "historical commission must not change when
     * the Agent's commission rule changes later" without needing to
     * version the rule table itself.
     *
     * firstOrCreate keyed on invoice_id mirrors grantPlanEntitlements()'s
     * own idempotency idiom above, on top of (not instead of) the
     * agent_commissions.invoice_id UNIQUE constraint and the
     * Invoice::isPaid() guard already covering this whole method — three
     * independent layers, matching how duplicate-callback safety is
     * already layered elsewhere in this class.
     */
    private function grantAgentCommission(Account $account, Invoice $invoice): void
    {
        if ($account->agent_id === null) {
            return;
        }

        $rule = AgentCommissionRule::where('agent_account_id', $account->agent_id)->first();

        if (! $rule) {
            // No commission rule configured for this Agent yet — a
            // disclosed, non-fatal configuration gap, same treatment as
            // grantPlanEntitlements()'s "no Plan row" branch above: never
            // a reason to fail an already-credited payment.
            Log::warning("InvoiceCreditService: no AgentCommissionRule for agent #{$account->agent_id} -- skipping commission for invoice #{$invoice->id}.");

            return;
        }

        $baseAmount = (float) $invoice->total_amount;
        $amount = $rule->type === 'percentage'
            ? round($baseAmount * ((float) $rule->value) / 100, 2)
            : (float) $rule->value;

        AgentCommission::firstOrCreate(
            ['invoice_id' => $invoice->id],
            [
                'agent_account_id' => $account->agent_id,
                'customer_account_id' => $account->id,
                'agent_commission_rule_id' => $rule->id,
                'rule_type' => $rule->type,
                'rule_value' => $rule->value,
                'base_amount' => $baseAmount,
                'amount' => $amount,
                'status' => 'confirmed',
            ],
        );
    }

    /**
     * Agent Commission Foundation — refund/reversal lifecycle. Called only
     * from PaymentWebhookController when a gateway webhook reports a
     * settled refund/reversal event for a previously-paid Invoice; never
     * part of the payment-success path above.
     *
     * "If the invoice has no Agent commission, do nothing" (spec, literal):
     * a direct customer, or an Agent customer whose purchase predates any
     * AgentCommissionRule, simply has no agent_commissions row for this
     * invoice_id — this is then a silent no-op, exactly like
     * grantAgentCommission()'s own "no rule configured" branch above.
     *
     * Idempotency mirrors markPaidAndCreditQuota()'s own pattern:
     * lockForUpdate() the one row for this invoice_id inside a transaction,
     * then check its CURRENT status rather than trusting the caller not to
     * have sent this twice — a commission already 'reversed' is left
     * completely untouched, so a duplicate/replayed refund webhook can
     * never reverse it twice. Only the lifecycle columns
     * (status/reversed_at/reversal_reference) are ever written here — the
     * original snapshot columns (rule_type, rule_value, base_amount,
     * amount, agent_commission_rule_id) are never touched, which is what
     * "historical commission must not change" means at the row level.
     *
     * @return bool true if this call actually performed the reversal
     *         (first to win the race); false if it was a no-op (no
     *         commission for this invoice, or already reversed).
     */
    public function reverseAgentCommission(int $invoiceId, ?string $reference = null): bool
    {
        return DB::transaction(function () use ($invoiceId, $reference) {
            $commission = AgentCommission::query()->lockForUpdate()->where('invoice_id', $invoiceId)->first();

            if (! $commission) {
                return false;
            }

            if ($commission->status === 'reversed') {
                return false;
            }

            $commission->forceFill([
                'status' => 'reversed',
                'reversed_at' => now(),
                'reversal_reference' => $reference,
            ])->save();

            return true;
        });
    }
}
