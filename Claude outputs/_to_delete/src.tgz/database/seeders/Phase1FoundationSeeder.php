<?php

namespace Database\Seeders;

use App\Models\Capability;
use App\Models\Plan;
use App\Models\Provider;
use Illuminate\Database\Seeder;

/**
 * Phase 1 Foundation — seeds the Capability/Provider/ProviderCapability/
 * Plan/PlanEntitlement tables. Idempotent (updateOrCreate throughout,
 * matching RolePermissionSeeder's own firstOrCreate convention) — safe
 * to re-run.
 *
 * Plan rows are value-identical to App\Support\PlanCatalog::PLANS,
 * which is NOT removed or modified by this seeder — the live checkout
 * flow keeps reading PlanCatalog unchanged in Phase 1. See the Phase 1
 * plan, Step 5, Task 4.
 */
class Phase1FoundationSeeder extends Seeder
{
    private const CAPABILITIES = [
        'whatsapp_send' => ['label' => 'WhatsApp Messaging', 'category' => 'whatsapp'],
        'whatsapp_groups' => ['label' => 'WhatsApp Groups', 'category' => 'whatsapp'],
        'crm' => ['label' => 'CRM', 'category' => 'growth'],
        'journey_automation' => ['label' => 'Journey Automation', 'category' => 'growth'],
        'ads' => ['label' => 'Ads', 'category' => 'growth'],
        'social' => ['label' => 'Social Media', 'category' => 'growth'],
        'ai' => ['label' => 'AI', 'category' => 'growth'],
    ];

    private const PROVIDERS = [
        'qr' => ['label' => 'WhatsApp QR (Baileys)', 'driver_class' => 'App\\Services\\WhatsApp\\BaileysDriver'],
        'meta' => ['label' => 'WhatsApp Meta Cloud API', 'driver_class' => 'App\\Services\\WhatsApp\\MetaCloudApiDriver'],
        'none' => ['label' => 'No WhatsApp Provider', 'driver_class' => null],
    ];

    /**
     * [provider_slug, capability_slug, supported, reason]. `reason`
     * states plainly whether a false is a genuine technical limitation
     * or a deliberate business/product-tier restriction — never left
     * implicit. See the Phase 1 plan, Step 6.
     */
    private const PROVIDER_CAPABILITIES = [
        ['qr', 'whatsapp_send', true, 'QR/Baileys sends text and template messages — existing, working, untouched.'],
        ['qr', 'whatsapp_groups', true, 'QR/Baileys group messaging is a real, maintained feature.'],
        ['qr', 'crm', false, 'Business/product-tier restriction: QR is messaging-only per the platform product rule and does not include CRM.'],
        ['qr', 'journey_automation', false, 'Business/product-tier restriction: QR does not get Journey automation.'],
        ['qr', 'ads', false, 'Business/product-tier restriction: QR does not get Ads; CTWA ad-lead capture is also Meta-webhook-specific.'],
        ['meta', 'whatsapp_send', true, 'MetaCloudApiDriver — existing.'],
        ['meta', 'whatsapp_groups', false, 'Technical limitation: Meta Cloud API cannot do WhatsApp Groups.'],
        ['meta', 'crm', true, 'Meta-tier customers may be entitled to CRM.'],
        ['meta', 'journey_automation', true, 'Meta-tier customers may be entitled to Journey automation.'],
        ['meta', 'ads', true, 'CTWA ad-lead capture is Meta-webhook-native.'],
        ['none', 'social', true, 'Social/AI do not require any WhatsApp engine.'],
        ['none', 'ai', true, 'Social/AI do not require any WhatsApp engine.'],
    ];

    /**
     * Value-identical to App\Support\PlanCatalog::PLANS.
     */
    private const PLANS = [
        'starter' => ['label' => 'Starter', 'price' => 499.00, 'duration_days' => 30, 'description' => '500 messages/month over the QR (Baileys) engine.', 'capability' => 'whatsapp_send', 'usage_limit' => 500],
        'growth' => ['label' => 'Growth', 'price' => 1999.00, 'duration_days' => 30, 'description' => '2,500 messages/month over the QR (Baileys) engine.', 'capability' => 'whatsapp_send', 'usage_limit' => 2500],
        'business' => ['label' => 'Business', 'price' => 7999.00, 'duration_days' => 30, 'description' => '10,000 messages/month over the official Meta Cloud API.', 'capability' => 'whatsapp_send', 'usage_limit' => 10000],
    ];

    public function run(): void
    {
        $capabilities = collect(self::CAPABILITIES)->mapWithKeys(
            fn (array $attrs, string $slug) => [$slug => Capability::updateOrCreate(['slug' => $slug], $attrs)]
        );

        $providers = collect(self::PROVIDERS)->mapWithKeys(
            fn (array $attrs, string $slug) => [$slug => Provider::updateOrCreate(['slug' => $slug], $attrs)]
        );

        foreach (self::PROVIDER_CAPABILITIES as [$providerSlug, $capabilitySlug, $supported, $reason]) {
            $providers[$providerSlug]->capabilities()->syncWithoutDetaching([
                $capabilities[$capabilitySlug]->id => ['supported' => $supported, 'reason' => $reason],
            ]);
        }

        foreach (self::PLANS as $slug => $attrs) {
            $plan = Plan::updateOrCreate(['slug' => $slug], [
                'label' => $attrs['label'],
                'price' => $attrs['price'],
                'duration_days' => $attrs['duration_days'],
                'description' => $attrs['description'],
            ]);

            $plan->capabilities()->syncWithoutDetaching([
                $capabilities[$attrs['capability']]->id => ['usage_limit' => $attrs['usage_limit']],
            ]);
        }
    }
}
