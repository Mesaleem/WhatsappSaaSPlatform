<?php

namespace Tests\Feature;

use App\Models\Account;
use App\Models\Capability;
use App\Models\Subscription;
use App\Models\User;
use Database\Seeders\Phase1FoundationSeeder;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Phase 1 Foundation, Task 7 — write-time provider-compatibility
 * enforcement on AccountController::grantEntitlement()/revokeEntitlement().
 */
class AccountEntitlementTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolePermissionSeeder::class);
        $this->seed(Phase1FoundationSeeder::class);
    }

    private function makeSuperAdmin(): User
    {
        $user = User::factory()->create(['account_id' => null]);
        $user->assignRole('super_admin');

        return $user;
    }

    private function makePlainAdmin(Account $account): User
    {
        $user = User::factory()->create(['account_id' => $account->id]);
        $user->assignRole('admin');

        return $user;
    }

    public function test_super_admin_can_grant_a_capability_supported_by_the_accounts_provider(): void
    {
        $account = Account::factory()->create();
        Subscription::factory()->for($account)->create(['engine_type' => 'meta']);
        $superAdmin = $this->makeSuperAdmin();

        $response = $this->actingAs($superAdmin)->postJson(
            "/api/admin/accounts/{$account->id}/entitlements",
            ['capability' => 'crm']
        );

        $response->assertOk();
        $this->assertDatabaseHas('account_entitlements', [
            'account_id' => $account->id,
            'capability_id' => Capability::where('slug', 'crm')->value('id'),
        ]);
    }

    public function test_grant_is_rejected_when_the_provider_does_not_support_the_capability(): void
    {
        $account = Account::factory()->create();
        Subscription::factory()->for($account)->create(['engine_type' => 'qr']);
        $superAdmin = $this->makeSuperAdmin();

        // QR does not support crm (business/product-tier restriction —
        // seeded by Phase1FoundationSeeder).
        $response = $this->actingAs($superAdmin)->postJson(
            "/api/admin/accounts/{$account->id}/entitlements",
            ['capability' => 'crm']
        );

        $response->assertStatus(422);
        $this->assertDatabaseMissing('account_entitlements', [
            'account_id' => $account->id,
            'capability_id' => Capability::where('slug', 'crm')->value('id'),
        ]);
    }

    public function test_a_non_super_admin_cannot_grant_entitlements(): void
    {
        $account = Account::factory()->create();
        Subscription::factory()->for($account)->create(['engine_type' => 'meta']);
        $admin = $this->makePlainAdmin($account);

        $response = $this->actingAs($admin)->postJson(
            "/api/admin/accounts/{$account->id}/entitlements",
            ['capability' => 'crm']
        );

        $response->assertForbidden();
    }

    public function test_super_admin_can_revoke_a_granted_capability(): void
    {
        $account = Account::factory()->create();
        Subscription::factory()->for($account)->create(['engine_type' => 'meta']);
        $capability = Capability::where('slug', 'crm')->firstOrFail();
        $account->entitlements()->create(['capability_id' => $capability->id, 'source' => 'manual_grant']);
        $superAdmin = $this->makeSuperAdmin();

        $response = $this->actingAs($superAdmin)->deleteJson(
            "/api/admin/accounts/{$account->id}/entitlements/crm"
        );

        $response->assertOk();
        $this->assertDatabaseMissing('account_entitlements', [
            'account_id' => $account->id,
            'capability_id' => $capability->id,
        ]);
    }

    public function test_provider_capability_service_reflects_the_seeded_qr_meta_split(): void
    {
        // Direct assertions on the seeded catalog itself — the exact
        // worked example locked for Phase 1 (QR: messaging/groups only;
        // Meta: no groups but yes crm/journey/ads).
        $this->assertTrue(app(\App\Services\Access\ProviderCapabilityService::class)->supports('qr', 'whatsapp_send'));
        $this->assertTrue(app(\App\Services\Access\ProviderCapabilityService::class)->supports('qr', 'whatsapp_groups'));
        $this->assertFalse(app(\App\Services\Access\ProviderCapabilityService::class)->supports('qr', 'journey_automation'));
        $this->assertFalse(app(\App\Services\Access\ProviderCapabilityService::class)->supports('meta', 'whatsapp_groups'));
        $this->assertTrue(app(\App\Services\Access\ProviderCapabilityService::class)->supports('meta', 'journey_automation'));
    }
}
